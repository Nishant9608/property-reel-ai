export interface PropertyImage {
  file: File;
  preview: string;
}

export interface PropertyData {
  title: string;
  address: string;
  price: string;
  bedrooms: number;
  bathrooms: number;
  sqft: number;
  agentName: string;
  phoneNumber: string;
  ctaText: string;
  images: PropertyImage[];
}

export interface ReelSettings {
  duration: number;
  music: 'none' | 'custom';
  customMusicFile?: File;
  customMusicUrl?: string;
  transitionSpeed: 'slow' | 'medium' | 'fast';
}
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "../ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Label } from "../ui/label";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { Music, ArrowLeft, ArrowRight } from "lucide-react";
import type { ReelSettings } from "../types";

interface ReelConfigProps {
  onBack: () => void;
  onNext: (settings: ReelSettings) => void;
}

export function ReelConfig({ onBack, onNext }: ReelConfigProps) {
  const [musicType, setMusicType] = useState<"none" | "custom">("none");
  const [customMusicUrl, setCustomMusicUrl] = useState<string>("");
  const [duration, setDuration] = useState(15);

  const handleSubmit = () => {
    const settings: ReelSettings = {
      music: musicType,
      customMusicUrl: musicType === 'custom' ? customMusicUrl : undefined,
      duration,
      transitionSpeed: "medium"
    };
    onNext(settings);
  };

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="max-w-3xl mx-auto space-y-6">
      <Card className="border-slate-800 bg-slate-900/50">
        <CardHeader><CardTitle className="text-slate-100">Configure Reel Style</CardTitle></CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <Label className="text-slate-300 flex items-center gap-2"><Music className="w-4 h-4 text-amber-400" /> Background Music</Label>
            <RadioGroup value={musicType} onValueChange={(v: any) => setMusicType(v)}>
              <div className="flex items-center space-x-2 p-4 border border-slate-700 rounded-lg hover:border-amber-500/50 transition-colors cursor-pointer"><RadioGroupItem value="none" id="none-music" /><Label htmlFor="none-music" className="flex-1 cursor-pointer"><span className="text-slate-100 font-medium">No Music (Silent)</span></Label></div>
              <div className="flex items-center space-x-2 p-4 border border-slate-700 rounded-lg hover:border-amber-500/50 transition-colors"><RadioGroupItem value="custom" id="custom-music" /><Label htmlFor="custom-music" className="flex-1 cursor-pointer"><span className="text-slate-100 font-medium">Custom Music URL</span></Label></div>
            </RadioGroup>
            {musicType === 'custom' && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="pl-6 space-y-2">
                <Label className="text-amber-400">Paste MP3 URL</Label>
                <input type="text" value={customMusicUrl} onChange={(e) => setCustomMusicUrl(e.target.value)} placeholder="https://example.com/music.mp3" className="w-full bg-slate-950 border-amber-500/50 text-white px-3 py-2 rounded-md focus:outline-none focus:border-amber-500" />
              </motion.div>
            )}
          </div>
          <div className="space-y-4">
            <div className="flex justify-between"><Label className="text-slate-300">Video Duration</Label><span className="text-amber-400 font-mono">{duration}s</span></div>
            <input type="range" min="10" max="60" step="5" value={duration} onChange={(e) => setDuration(Number(e.target.value))} className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500" />
          </div>
        </CardContent>
      </Card>
      <div className="flex justify-between pt-4">
        <Button variant="ghost" onClick={onBack} className="text-slate-400 hover:text-slate-100"><ArrowLeft className="w-4 h-4 mr-2" />Back</Button>
        <Button onClick={handleSubmit} className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-semibold px-8">Generate Video<ArrowRight className="w-4 h-4 ml-2" /></Button>
      </div>
    </motion.div>
  );
}
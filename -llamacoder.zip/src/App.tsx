import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { PropertyUpload } from "./components/PropertyUpload";
import { ReelConfig } from "./components/ReelConfig";
import { PreviewPlayer } from "./components/PreviewPlayer";
import { ProcessingState } from "./components/ProcessingState";
import { Button } from "../components/ui/button";
import { Home, Film, Wand2, CheckCircle } from "lucide-react";
import type { PropertyData, ReelSettings } from "./types";

type Step = "upload" | "config" | "processing" | "complete";

export default function App() {
  const [currentStep, setCurrentStep] = useState<Step>("upload");
  const [propertyData, setPropertyData] = useState<PropertyData | null>(null);
  const [reelSettings, setReelSettings] = useState<ReelSettings | null>(null);

  const handleUploadComplete = (data: PropertyData) => {
    setPropertyData(data);
    setCurrentStep("config");
  };

  const handleConfigComplete = (settings: ReelSettings) => {
    setReelSettings(settings);
    setCurrentStep("processing");
  };

  const handleProcessingComplete = () => {
    setCurrentStep("complete");
  };

  const handleReset = () => {
    setCurrentStep("upload");
    setPropertyData(null);
    setReelSettings(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-amber-500/30">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
              <Film className="w-5 h-5 text-slate-900" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-amber-400 to-amber-200 bg-clip-text text-transparent">
              ReelAI
            </span>
          </div>
          
          {/* Progress Steps */}
          <div className="hidden md:flex items-center gap-2">
            <StepIcon icon={Home} label="Upload" active={currentStep === "upload"} completed={["config", "processing", "complete"].includes(currentStep)} />
            <div className="w-8 h-px bg-slate-700" />
            <StepIcon icon={Wand2} label="Configure" active={currentStep === "config"} completed={["processing", "complete"].includes(currentStep)} />
            <div className="w-8 h-px bg-slate-700" />
            <StepIcon icon={CheckCircle} label="Finish" active={currentStep === "complete"} completed={false} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          {currentStep === "upload" && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <PropertyUpload onComplete={handleUploadComplete} />
            </motion.div>
          )}

          {currentStep === "config" && (
            <motion.div
              key="config"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <ReelConfig 
                onBack={() => setCurrentStep("upload")} 
                onNext={handleConfigComplete} 
              />
            </motion.div>
          )}

          {currentStep === "processing" && propertyData && reelSettings && (
            <motion.div
              key="processing"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
            >
              <ProcessingState onComplete={handleProcessingComplete} />
            </motion.div>
          )}

          {currentStep === "complete" && propertyData && reelSettings && (
            <motion.div
              key="complete"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <PreviewPlayer
                propertyData={propertyData}
                reelSettings={reelSettings}
                onStartGeneration={() => {}} // Already generated
                onReset={handleReset}
                isComplete={true}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

function StepIcon({ icon: Icon, label, active, completed }: { icon: any, label: string, active: boolean, completed: boolean }) {
  return (
    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full transition-colors ${
      active ? "bg-amber-500/10 text-amber-400" : completed ? "text-emerald-400" : "text-slate-500"
    }`}>
      <Icon className="w-4 h-4" />
      <span className="text-sm font-medium">{label}</span>
    </div>
  );
}
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Label } from "../../components/ui/label";
import { RadioGroup, RadioGroupItem } from "../../components/ui/radio-group";
import { Music, Upload, ArrowLeft, ArrowRight, Volume2 } from "lucide-react";
import type { ReelSettings } from "../types";

interface ReelConfigProps {
  onBack: () => void;
  onNext: (settings: ReelSettings) => void;
}

export function ReelConfig({ onBack, onNext }: ReelConfigProps) {
  const [style, setStyle] = useState("cinematic");
  const [musicType, setMusicType] = useState<"default" | "custom">("default");
  const [customMusic, setCustomMusic] = useState<File | null>(null);
  const [duration, setDuration] = useState(15); // seconds

  const handleSubmit = () => {
    const settings: ReelSettings = {
      style,
      music: musicType,
      customMusicFile: customMusic || undefined,
      duration,
      transitionSpeed: "smooth"
    };
    onNext(settings);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="max-w-3xl mx-auto space-y-6"
    >
      <Card className="border-slate-800 bg-slate-900/50">
        <CardHeader>
          <CardTitle className="text-slate-100">Configure Reel Style</CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          
          {/* Music Selection */}
          <div className="space-y-4">
            <Label className="text-slate-300 flex items-center gap-2">
              <Music className="w-4 h-4 text-amber-400" />
              Background Music
            </Label>
            
            <RadioGroup value={musicType} onValueChange={(v: any) => setMusicType(v)}>
              <div className="flex items-center space-x-2 p-4 border border-slate-700 rounded-lg hover:border-amber-500/50 transition-colors cursor-pointer">
                <RadioGroupItem value="default" id="default-music" />
                <Label htmlFor="default-music" className="flex-1 cursor-pointer">
                  <span className="text-slate-100 font-medium">Calm Piano (Default)</span>
                  <p className="text-slate-500 text-sm">Royalty-free ambient track</p>
                </Label>
                <Volume2 className="w-5 h-5 text-slate-500" />
              </div>

              <div className="flex items-center space-x-2 p-4 border border-slate-700 rounded-lg hover:border-amber-500/50 transition-colors">
                <RadioGroupItem value="custom" id="custom-music" />
                <Label htmlFor="custom-music" className="flex-1 cursor-pointer">
                  <span className="text-slate-100 font-medium">Upload Your Own</span>
                  <p className="text-slate-500 text-sm">MP3 or WAV file</p>
                </Label>
                {musicType === 'custom' && (
                  <label className="cursor-pointer bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-md text-sm text-slate-300 transition-colors">
                    <input 
                      type="file" 
                      accept="audio/*" 
                      className="hidden" 
                      onChange={(e) => setCustomMusic(e.target.files?.[0] || null)}
                    />
                    {customMusic ? "Change" : "Select File"}
                  </label>
                )}
              </div>
            </RadioGroup>

            {musicType === 'custom' && customMusic && (
              <div className="flex items-center gap-2 text-sm text-emerald-400 bg-emerald-500/10 p-2 rounded">
                <Upload className="w-4 h-4" />
                {customMusic.name}
              </div>
            )}
          </div>

          {/* Duration Slider */}
          <div className="space-y-4">
            <div className="flex justify-between">
              <Label className="text-slate-300">Video Duration</Label>
              <span className="text-amber-400 font-mono">{duration}s</span>
            </div>
            <input
              type="range"
              min="10"
              max="60"
              step="5"
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex justify-between text-xs text-slate-500">
              <span>10s (Fast)</span>
              <span>60s (Detailed)</span>
            </div>
          </div>

        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between pt-4">
        <Button variant="ghost" onClick={onBack} className="text-slate-400 hover:text-slate-100">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button
          onClick={handleSubmit}
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-semibold px-8"
        >
          Generate Video
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  );
}
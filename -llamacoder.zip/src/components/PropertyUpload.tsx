import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Upload, X, MapPin, Bed, Bath, Maximize, User, Phone, Megaphone } from "lucide-react";
import type { PropertyData } from "../types";

interface PropertyUploadProps {
  onComplete: (data: PropertyData) => void;
}

export function PropertyUpload({ onComplete }: PropertyUploadProps) {
  const [images, setImages] = useState<{ file: File; preview: string }[]>([]);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
    bedrooms: "",
    bathrooms: "",
    sqft: "",
    agentName: "",
    phoneNumber: "",
    ctaText: "Call Now for Viewing!"
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const newImages = files.map(file => ({
      file,
      preview: URL.createObjectURL(file)
    }));
    setImages(prev => [...prev, ...newImages]);
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    if (images.length === 0) return alert("Please upload at least one image");
    
    const data: PropertyData = {
      title: formData.title || "Luxury Property",
      description: formData.description,
      price: formData.price || "Contact for Price",
      bedrooms: parseInt(formData.bedrooms) || 0,
      bathrooms: parseInt(formData.bathrooms) || 0,
      sqft: parseInt(formData.sqft) || 0,
      images,
      agentName: formData.agentName || "Your Agent",
      phoneNumber: formData.phoneNumber || "555-0123",
      ctaText: formData.ctaText
    };
    onComplete(data);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-6"
    >
      <div className="text-center space-y-2 mb-8">
        <h1 className="text-4xl font-bold text-slate-100">Create Property Reel</h1>
        <p className="text-slate-400">Upload photos and details to generate a 9:16 video</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Left Column: Uploads */}
        <Card className="border-slate-800 bg-slate-900/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Property Photos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border-2 border-dashed border-slate-700 rounded-lg p-8 text-center hover:border-amber-400/50 transition-colors cursor-pointer">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="image-upload"
              />
              <label htmlFor="image-upload" className="cursor-pointer">
                <Upload className="w-12 h-12 mx-auto text-slate-500 mb-4" />
                <p className="text-slate-300 font-medium">Click to upload images</p>
                <p className="text-slate-500 text-sm mt-1">PNG, JPG up to 10MB</p>
              </label>
            </div>

            {images.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {images.map((img, index) => (
                  <div key={index} className="relative aspect-square rounded-lg overflow-hidden group">
                    <img src={img.preview} alt={`Upload ${index}`} className="w-full h-full object-cover" />
                    <button
                      onClick={() => removeImage(index)}
                      className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4 text-white" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right Column: Details */}
        <Card className="border-slate-800 bg-slate-900/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Property Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Property Title</Label>
              <Input 
                placeholder="e.g. Modern Villa with Pool" 
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                className="bg-slate-800 border-slate-700 text-slate-100"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-300">Price</Label>
                <Input 
                  placeholder="$1,250,000" 
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: e.target.value})}
                  className="bg-slate-800 border-slate-700 text-slate-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-300">Sq Ft</Label>
                <Input 
                  placeholder="2500" 
                  type="number"
                  value={formData.sqft}
                  onChange={(e) => setFormData({...formData, sqft: e.target.value})}
                  className="bg-slate-800 border-slate-700 text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-slate-300">Beds</Label>
                <Input 
                  placeholder="4" 
                  type="number"
                  value={formData.bedrooms}
                  onChange={(e) => setFormData({...formData, bedrooms: e.target.value})}
                  className="bg-slate-800 border-slate-700 text-slate-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-300">Baths</Label>
                <Input 
                  placeholder="3" 
                  type="number"
                  value={formData.bathrooms}
                  onChange={(e) => setFormData({...formData, bathrooms: e.target.value})}
                  className="bg-slate-800 border-slate-700 text-slate-100"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-slate-300">Description</Label>
              <Textarea 
                placeholder="Describe the property..." 
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="bg-slate-800 border-slate-700 text-slate-100 min-h-[80px]"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contact Info for Video Overlay */}
      <Card className="border-slate-800 bg-slate-900/50">
        <CardHeader>
          <CardTitle className="text-slate-100 flex items-center gap-2">
            <User className="w-5 h-5 text-amber-400" />
            Video Overlay Info
          </CardTitle>
        </CardHeader>
        <CardContent className="grid md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label className="text-slate-300">Agent Name</Label>
            <Input 
              placeholder="John Doe" 
              value={formData.agentName}
              onChange={(e) => setFormData({...formData, agentName: e.target.value})}
              className="bg-slate-800 border-slate-700 text-slate-100"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-slate-300">Phone Number</Label>
            <Input 
              placeholder="(555) 123-4567" 
              value={formData.phoneNumber}
              onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
              className="bg-slate-800 border-slate-700 text-slate-100"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-slate-300">Call to Action</Label>
            <Input 
              placeholder="Call Now!" 
              value={formData.ctaText}
              onChange={(e) => setFormData({...formData, ctaText: e.target.value})}
              className="bg-slate-800 border-slate-700 text-slate-100"
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleSubmit}
          disabled={images.length === 0}
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-semibold px-8 py-6 text-lg"
        >
          Next: Configure Reel
        </Button>
      </div>
    </motion.div>
  );
}
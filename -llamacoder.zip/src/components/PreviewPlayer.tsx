import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { VideoGenerator } from "./VideoGenerator";
import { Play, RefreshCw, ChevronLeft, ChevronRight, Pause, Sparkles } from "lucide-react";
import type { PropertyData, ReelSettings } from "../types";

interface PreviewPlayerProps {
  propertyData: PropertyData;
  reelSettings: ReelSettings;
  onReset: () => void;
}

export function PreviewPlayer({ propertyData, reelSettings, onReset }: PreviewPlayerProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showGenerator, setShowGenerator] = useState(false);

  // Auto-play logic for slideshow preview
  // Note: This is just a preview. The real video generation happens in VideoGenerator
  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % propertyData.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + propertyData.images.length) % propertyData.images.length);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleGenerateVideo = () => {
    setShowGenerator(true);
  };

  if (showGenerator) {
    return (
      <VideoGenerator 
        propertyData={propertyData} 
        reelSettings={reelSettings} 
        onComplete={onReset} 
      />
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto space-y-6"
    >
      {/* Preview Card - 9:16 Aspect Ratio Container */}
      <Card className="border-slate-800 bg-slate-950 overflow-hidden shadow-2xl shadow-amber-900/10 mx-auto" style={{ maxWidth: '400px' }}>
        <CardContent className="p-0">
          <div className="relative aspect-[9/16] bg-slate-950">
            {/* Main Image */}
            <AnimatePresence mode="wait">
              <motion.img
                key={currentImageIndex}
                src={propertyData.images[currentImageIndex].preview}
                alt="Property"
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="w-full h-full object-cover"
              />
            </AnimatePresence>

            {/* Overlay Gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40" />

            {/* Simulated Overlays (Visual Preview Only) */}
            <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent">
               <p className="text-amber-400 font-bold text-sm">{propertyData.agentName}</p>
               <p className="text-white text-xs">{propertyData.phoneNumber}</p>
            </div>

            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent">
              <p className="text-amber-400 font-bold text-xl">{propertyData.price}</p>
              <p className="text-white font-bold text-lg leading-tight mb-1">{propertyData.title}</p>
              <p className="text-slate-300 text-xs">{propertyData.bedrooms} bed • {propertyData.bathrooms} bath • {propertyData.sqft} sqft</p>
            </div>

            {/* Navigation Arrows */}
            <button
              onClick={(e) => { e.stopPropagation(); prevImage(); }}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center transition-colors"
            >
              <ChevronLeft className="w-4 h-4 text-white" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); nextImage(); }}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center transition-colors"
            >
              <ChevronRight className="w-4 h-4 text-white" />
            </button>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-4 justify-center pt-4">
        <Button
          onClick={handleGenerateVideo}
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-semibold px-10 py-6 text-lg shadow-lg shadow-amber-900/20"
        >
          <Sparkles className="w-5 h-5 mr-2" />
          Generate 9:16 Video
        </Button>

        <Button variant="ghost" onClick={onReset} className="text-slate-400 hover:text-slate-100 px-6 h-14">
          <RefreshCw className="w-4 h-4 mr-2" />
          Start Over
        </Button>
      </div>
      
      <p className="text-center text-slate-500 text-sm mt-4">
        Preview mode. Click "Generate" to render the actual video file with text overlays.
      </p>
    </motion.div>
  );
}
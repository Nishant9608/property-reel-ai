import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { RadioGroup, RadioGroupItem } from "../../components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Button } from "../../components/ui/button";
import { Music, Link, Zap } from "lucide-react";
import type { PropertyData, ReelSettings } from "../types";

interface PropertyFormProps {
  propertyData: PropertyData;
  reelSettings: ReelSettings;
  onPropertyChange: (data: PropertyData) => void;
  onSettingsChange: (settings: ReelSettings) => void;
  onNext: () => void;
}

export function PropertyForm({ propertyData, reelSettings, onPropertyChange, onSettingsChange, onNext }: PropertyFormProps) {
  const handlePropertyChange = (field: keyof PropertyData, value: any) => {
    onPropertyChange({ ...propertyData, [field]: value });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Property Details</h2>
        <p className="text-slate-400">Enter the information for your listing</p>
      </div>

      <Card className="border-slate-800 bg-slate-900/50">
        <CardHeader>
          <CardTitle className="text-white">Listing Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Property Title</Label>
              <Input
                value={propertyData.title}
                onChange={(e) => handlePropertyChange("title", e.target.value)}
                placeholder="Luxury Modern Villa"
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Price</Label>
              <Input
                value={propertyData.price}
                onChange={(e) => handlePropertyChange("price", e.target.value)}
                placeholder="$1,250,000"
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">Address</Label>
            <Input
              value={propertyData.address}
              onChange={(e) => handlePropertyChange("address", e.target.value)}
              placeholder="123 Ocean Drive, Miami, FL"
              className="bg-slate-950 border-slate-700 text-white"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Beds</Label>
              <Input
                type="number"
                value={propertyData.bedrooms}
                onChange={(e) => handlePropertyChange("bedrooms", parseInt(e.target.value))}
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Baths</Label>
              <Input
                type="number"
                value={propertyData.bathrooms}
                onChange={(e) => handlePropertyChange("bathrooms", parseInt(e.target.value))}
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Sq Ft</Label>
              <Input
                type="number"
                value={propertyData.sqft}
                onChange={(e) => handlePropertyChange("sqft", parseInt(e.target.value))}
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Agent Name</Label>
              <Input
                value={propertyData.agentName}
                onChange={(e) => handlePropertyChange("agentName", e.target.value)}
                placeholder="John Doe"
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-slate-300">Phone Number</Label>
              <Input
                value={propertyData.phoneNumber}
                onChange={(e) => handlePropertyChange("phoneNumber", e.target.value)}
                placeholder="+1 (555) 123-4567"
                className="bg-slate-950 border-slate-700 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">Call to Action Text</Label>
            <Input
              value={propertyData.ctaText}
              onChange={(e) => handlePropertyChange("ctaText", e.target.value)}
              placeholder="Contact Agent"
              className="bg-slate-950 border-slate-700 text-white"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-800 bg-slate-900/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Music className="w-5 h-5 text-amber-500" />
            Reel Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Label className="text-slate-300">Music Selection</Label>
            <RadioGroup
              value={reelSettings.music}
              onValueChange={(value: any) => onSettingsChange({ ...reelSettings, music: value })}
              className="flex flex-col space-y-2"
            >
              <div className="flex items-center space-x-2 p-3 rounded-lg border border-slate-700 bg-slate-950/50">
                <RadioGroupItem value="none" id="none" />
                <Label htmlFor="none" className="flex-1 cursor-pointer text-slate-200">No Music (Silent)</Label>
              </div>
              
              <div className="flex items-center space-x-2 p-3 rounded-lg border border-slate-700 bg-slate-950/50">
                <RadioGroupItem value="custom" id="custom" />
                <Label htmlFor="custom" className="flex-1 cursor-pointer text-slate-200">Custom Music URL</Label>
              </div>
            </RadioGroup>

            {reelSettings.music === 'custom' && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-2 pl-6"
              >
                <Label className="text-amber-400 flex items-center gap-2">
                  <Link className="w-4 h-4" />
                  Paste Direct MP3 URL
                </Label>
                <Input
                  value={reelSettings.customMusicUrl || ''}
                  onChange={(e) => onSettingsChange({ ...reelSettings, customMusicUrl: e.target.value })}
                  placeholder="https://example.com/music.mp3"
                  className="bg-slate-950 border-amber-500/50 text-white focus:border-amber-500"
                />
                <p className="text-xs text-slate-500">
                  Paste the direct link to your audio file here.
                </p>
              </motion.div>
            )}
          </div>

          <div className="space-y-2">
            <Label className="text-slate-300">Duration</Label>
            <Select
              value={reelSettings.duration.toString()}
              onValueChange={(value) => onSettingsChange({ ...reelSettings, duration: parseInt(value) })}
            >
              <SelectTrigger className="bg-slate-950 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-950 border-slate-700">
                <SelectItem value="10">10 seconds</SelectItem>
                <SelectItem value="15">15 seconds</SelectItem>
                <SelectItem value="30">30 seconds</SelectItem>
                <SelectItem value="60">60 seconds</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Button 
        onClick={onNext}
        className="w-full h-14 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-bold text-lg rounded-xl shadow-lg shadow-amber-900/20 flex items-center justify-center gap-3"
      >
        <Zap className="w-5 h-5" />
        Generate Reel
      </Button>
    </div>
  );
}
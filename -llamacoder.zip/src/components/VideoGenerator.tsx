import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Download, CheckCircle, Play, RotateCcw, Share2, Smartphone } from "lucide-react";
import type { PropertyData, ReelSettings } from "../types";

interface VideoGeneratorProps {
  propertyData: PropertyData;
  reelSettings: ReelSettings;
  onComplete: () => void;
}

export function VideoGenerator({ propertyData, reelSettings, onComplete }: VideoGeneratorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isGenerating, setIsGenerating] = useState(true);
  const [progress, setProgress] = useState(0);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [statusText, setStatusText] = useState("Initializing...");
  const [fileExtension, setFileExtension] = useState<string>("mp4");
  const [videoFile, setVideoFile] = useState<File | null>(null);

  useEffect(() => {
    generateVideo();
  }, []);

  const generateVideo = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = 540; 
    const height = 960;
    canvas.width = width;
    canvas.height = height;

    // 1. Load Images
    setStatusText("Loading images...");
    const loadedImages: HTMLImageElement[] = [];
    for (const img of propertyData.images) {
      const image = new Image();
      image.src = img.preview;
      await new Promise((resolve) => { image.onload = resolve; });
      loadedImages.push(image);
    }

    // 2. Setup Audio (ONLY if Custom URL is provided)
    let audioContext: AudioContext | null = null;
    let audioSource: AudioBufferSourceNode | null = null;
    let audioDest: MediaStreamAudioDestinationNode | null = null;
    let hasAudio = false;

    if (reelSettings.music === 'custom' && (reelSettings.customMusicUrl || reelSettings.customMusicFile)) {
      setStatusText("Preparing custom audio...");
      try {
        audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        audioDest = audioContext.createMediaStreamDestination();
        
        let audioUrl = "";
        if (reelSettings.customMusicUrl) {
          audioUrl = reelSettings.customMusicUrl;
        } else if (reelSettings.customMusicFile) {
          audioUrl = URL.createObjectURL(reelSettings.customMusicFile);
        }

        const response = await fetch(audioUrl);
        const arrayBuffer = await response.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        
        audioSource = audioContext.createBufferSource();
        audioSource.buffer = audioBuffer;
        audioSource.loop = true; 
        audioSource.connect(audioDest);
        hasAudio = true;
      } catch (e) {
        console.warn("Custom audio failed, rendering silent video", e);
        hasAudio = false;
      }
    }

    // 3. Setup Stream
    const canvasStream = canvas.captureStream(30);
    
    // Combine streams only if audio exists
    const tracks = [...canvasStream.getVideoTracks()];
    if (hasAudio && audioDest) {
      tracks.push(...audioDest.stream.getAudioTracks());
    }
    const combinedStream = new MediaStream(tracks);

    let mimeType = "video/mp4";
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = "video/webm;codecs=vp9,opus";
      setFileExtension("webm");
    }

    const mediaRecorder = new MediaRecorder(combinedStream, { mimeType });
    const chunks: BlobPart[] = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType });
      const url = URL.createObjectURL(blob);
      const file = new File([blob], `property-reel-${Date.now()}.${fileExtension}`, { type: mimeType });
      
      setVideoUrl(url);
      setVideoFile(file);
      setIsGenerating(false);
      setStatusText("Complete!");
      audioContext?.close();
    };

    mediaRecorder.start();
    if (audioSource) audioSource.start(0);

    // 4. Animation Loop
    setStatusText("Rendering frames...");
    const totalDuration = reelSettings.duration * 1000;
    const fps = 30;
    const totalFrames = (totalDuration / 1000) * fps;
    const framesPerImage = totalFrames / loadedImages.length;
    
    let currentFrame = 0;

    const drawFrame = () => {
      const imageIndex = Math.floor(currentFrame / framesPerImage);
      const frameInImage = currentFrame % framesPerImage;
      const progress = frameInImage / framesPerImage;

      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, width, height);

      const img = loadedImages[imageIndex];
      const imgRatio = img.width / img.height;
      const canvasRatio = width / height;
      
      let drawWidth, drawHeight, offsetX, offsetY;
      if (imgRatio > canvasRatio) {
        drawHeight = height;
        drawWidth = height * imgRatio;
        offsetX = (width - drawWidth) / 2;
        offsetY = 0;
      } else {
        drawWidth = width;
        drawHeight = width / imgRatio;
        offsetX = 0;
        offsetY = (height - drawHeight) / 2;
      }

      const zoomFactor = 1 + (progress * 0.15); 
      const zoomedWidth = drawWidth * zoomFactor;
      const zoomedHeight = drawHeight * zoomFactor;
      const zoomOffsetX = (width - zoomedWidth) / 2;
      const zoomOffsetY = (height - zoomedHeight) / 2;

      ctx.drawImage(img, zoomOffsetX, zoomOffsetY, zoomedWidth, zoomedHeight);

      // Overlays
      ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
      ctx.fillRect(0, 0, width, 90);
      ctx.fillStyle = "#fff";
      ctx.font = "bold 26px system-ui, sans-serif";
      ctx.fillText(propertyData.agentName, 20, 45);
      ctx.font = "22px system-ui, sans-serif";
      ctx.fillStyle = "#fbbf24";
      ctx.fillText(propertyData.phoneNumber, 20, 75);

      const bottomHeight = 250;
      const gradient = ctx.createLinearGradient(0, height - bottomHeight, 0, height);
      gradient.addColorStop(0, "rgba(0,0,0,0)");
      gradient.addColorStop(0.3, "rgba(0,0,0,0.8)");
      gradient.addColorStop(1, "rgba(0,0,0,1)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, height - bottomHeight, width, bottomHeight);

      ctx.fillStyle = "#fbbf24";
      ctx.font = "bold 48px system-ui, sans-serif";
      ctx.fillText(propertyData.price, 20, height - 150);

      ctx.fillStyle = "#fff";
      ctx.font = "bold 32px system-ui, sans-serif";
      const words = propertyData.title.split(' ');
      let line = '';
      let y = height - 100;
      for(let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > width - 40 && n > 0) {
          ctx.fillText(line, 20, y);
          line = words[n] + ' ';
          y += 35;
        } else {
          line = testLine;
        }
      }
      ctx.fillText(line, 20, y);

      ctx.font = "20px system-ui, sans-serif";
      ctx.fillStyle = "#cbd5e1";
      const details = `${propertyData.bedrooms} Bed • ${propertyData.bathrooms} Bath • ${propertyData.sqft.toLocaleString()} Sq Ft`;
      ctx.fillText(details, 20, height - 40);

      const btnWidth = 240;
      const btnHeight = 60;
      const btnX = width - btnWidth - 20;
      const btnY = height - btnHeight - 20;

      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.beginPath();
      ctx.roundRect(btnX + 4, btnY + 4, btnWidth, btnHeight, 30);
      ctx.fill();

      ctx.fillStyle = "#fbbf24";
      ctx.beginPath();
      ctx.roundRect(btnX, btnY, btnWidth, btnHeight, 30);
      ctx.fill();

      ctx.fillStyle = "#000";
      ctx.font = "bold 24px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(propertyData.ctaText, btnX + btnWidth / 2, btnY + btnHeight / 2);
      
      ctx.textAlign = "left";
      ctx.textBaseline = "alphabetic";

      currentFrame++;
      setProgress(Math.round((currentFrame / totalFrames) * 100));

      if (currentFrame < totalFrames) {
        requestAnimationFrame(drawFrame);
      } else {
        mediaRecorder.stop();
        if (audioSource) audioSource.stop();
      }
    };

    drawFrame();
  };

  const handleDownload = () => {
    if (!videoUrl) return;
    const a = document.createElement("a");
    a.href = videoUrl;
    a.download = `property-reel-${Date.now()}.${fileExtension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShare = async () => {
    // Try to share the file directly (Mobile)
    if (videoFile && navigator.share && navigator.canShare({ files: [videoFile] })) {
      try {
        await navigator.share({
          files: [videoFile],
          title: propertyData.title,
          text: `Check out this property: ${propertyData.title} - ${propertyData.price}`,
        });
        return;
      } catch (err) {
        console.error("Native share failed", err);
      }
    }
    
    // Fallback: Copy the App URL (Desktop or if file share fails)
    try {
      await navigator.clipboard.writeText(window.location.href);
      alert("App link copied to clipboard! Share this with friends.");
    } catch (err) {
      console.error("Failed to copy", err);
    }
  };

  return (
    <div className="max-w-4xl mx-auto pb-12">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Your Reel is Ready</h2>
        <p className="text-slate-400">High-quality 9:16 video</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 items-start">
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-amber-500 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
          <Card className="relative border-slate-800 bg-slate-950 rounded-2xl overflow-hidden shadow-2xl">
            <CardContent className="p-2">
              <div className="relative aspect-[9/16] bg-slate-900 rounded-xl overflow-hidden">
                <canvas 
                  ref={canvasRef} 
                  className="w-full h-full object-contain"
                />
                {videoUrl && (
                  <video 
                    ref={videoRef}
                    src={videoUrl}
                    controls
                    className="absolute inset-0 w-full h-full object-contain"
                  />
                )}
                {isGenerating && (
                  <div className="absolute inset-0 bg-slate-950/80 flex flex-col items-center justify-center backdrop-blur-sm z-10">
                    <div className="w-16 h-16 border-4 border-amber-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                    <p className="text-amber-400 font-semibold">{statusText}</p>
                    <p className="text-slate-400 text-sm mt-1">{progress}%</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {!isGenerating && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <Card className="border-emerald-500/30 bg-emerald-950/20 backdrop-blur-sm">
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/20 flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-emerald-400 font-bold">Rendering Complete</h3>
                    <p className="text-slate-400 text-sm">Video is ready for download and sharing.</p>
                  </div>
                </CardContent>
              </Card>

              <Button 
                onClick={handleDownload}
                className="w-full h-16 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-bold text-xl rounded-xl shadow-lg shadow-amber-900/20 flex items-center justify-center gap-3 group"
              >
                <Download className="w-6 h-6 group-hover:animate-bounce" />
                Download Video (.{fileExtension.toUpperCase()})
              </Button>

              <div className="grid grid-cols-2 gap-4">
                <Button 
                  variant="outline" 
                  className="border-slate-700 text-slate-300 hover:bg-slate-800 h-14"
                  onClick={handleShare}
                >
                  <Smartphone className="w-4 h-4 mr-2" />
                  Share App
                </Button>
                <Button 
                  variant="outline" 
                  className="border-slate-700 text-slate-300 hover:bg-slate-800 h-14"
                  onClick={() => videoRef.current?.play()}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Replay
                </Button>
              </div>

              <Button 
                variant="ghost" 
                className="w-full text-slate-400 hover:text-slate-100 h-12"
                onClick={onComplete}
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Create New Project
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
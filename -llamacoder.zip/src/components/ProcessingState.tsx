import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "../../components/ui/card";
import { Loader2, CheckCircle, Sparkles, Video, Wand2 } from "lucide-react";

interface ProcessingStateProps {
  onComplete: () => void;
}

export function ProcessingState({ onComplete }: ProcessingStateProps) {
  const [progress, setProgress] = useState(0);
  const [currentStage, setCurrentStage] = useState(0);

  const stages = [
    { icon: Wand2, label: "Analyzing Property Details" },
    { icon: Video, label: "Generating Transitions" },
    { icon: Sparkles, label: "Applying AI Enhancements" },
    { icon: CheckCircle, label: "Finalizing Video" },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => onComplete(), 500); // Small delay before showing result
          return 100;
        }
        return prev + 1;
      });
    }, 50); // Speed of simulation

    return () => clearInterval(interval);
  }, [onComplete]);

  useEffect(() => {
    const stageIndex = Math.min(Math.floor((progress / 100) * stages.length), stages.length - 1);
    setCurrentStage(stageIndex);
  }, [progress, stages.length]);

  return (
    <div className="max-w-2xl mx-auto py-12">
      <Card className="border-slate-800 bg-slate-900/50 overflow-hidden">
        <CardContent className="p-12 text-center space-y-8">
          {/* Animated Loader */}
          <div className="relative w-32 h-32 mx-auto">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 border-4 border-slate-800 border-t-amber-400 rounded-full"
            />
            <div className="absolute inset-4 flex items-center justify-center">
              <Loader2 className="w-12 h-12 text-amber-400 animate-spin" />
            </div>
          </div>

          {/* Progress Text */}
          <div className="space-y-2">
            <motion.h2 
              key={currentStage}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-2xl font-bold text-slate-100"
            >
              {stages[currentStage].label}
            </motion.h2>
            <p className="text-slate-400">Please wait while we create your cinematic reel...</p>
          </div>

          {/* Progress Bar */}
          <div className="space-y-3">
            <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-amber-500 to-amber-400"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>
            <p className="text-sm font-medium text-amber-400">{progress}% Complete</p>
          </div>

          {/* Stage Indicators */}
          <div className="flex justify-center gap-4 pt-4">
            {stages.map((stage, index) => {
              const Icon = stage.icon;
              const isActive = index === currentStage;
              const isPast = index < currentStage;

              return (
                <div key={index} className="flex flex-col items-center gap-2">
                  <motion.div
                    animate={{
                      scale: isActive ? 1.2 : 1,
                      backgroundColor: isActive ? "rgba(251, 191, 36, 0.2)" : isPast ? "rgba(16, 185, 129, 0.2)" : "rgba(51, 65, 85, 0.5)"
                    }}
                    className="w-12 h-12 rounded-full flex items-center justify-center transition-colors"
                  >
                    <Icon 
                      className={`w-6 h-6 ${
                        isActive ? "text-amber-400" : isPast ? "text-emerald-400" : "text-slate-600"
                      }`} 
                    />
                  </motion.div>
                  <span className={`text-xs font-medium ${
                    isActive ? "text-amber-400" : isPast ? "text-emerald-400" : "text-slate-600"
                  }`}>
                    {stage.label}
                  </span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}